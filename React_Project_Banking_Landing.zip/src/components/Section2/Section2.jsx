
const Section2 = () => {
  return (
    <div className="h-screen bg-amber-900">Section2</div>
  )
}

export default Section2